DROP TABLE gis_dt;
CREATE TABLE gis_dt AS
SELECT SYSDATE + ROUND(DBMS_RANDOM.value(-12, 18)) dt,
       '블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다 블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다' v1,
       '블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다 블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다' v2,
       '블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다 블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다' v3,
       '블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다 블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다' v4,
       '블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다 블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다블록의 사이즈를 강제로 키우기 위한 더미 데이터 입니다' v5
FROM dual
CONNECT BY LEVEL <= 1000000;

CREATE INDEX idx_n_gis_dt_01 ON gis_dt (dt);



EXPLAIN PLAN FOR
SELECT DISTINCT TO_CHAR(DT, 'YYYYMMDD')
FROM gis_dt
WHERE DT BETWEEN TO_DATE('20200201', 'YYYYMMDD') AND TO_DATE('20200229 235959', 'YYYYMMDD HH24MISS');

EXPLAIN PLAN FOR
SELECT TO_CHAR(DT, 'YYYYMMDD')
FROM gis_dt
WHERE DT BETWEEN TO_DATE('20200201', 'YYYYMMDD') AND TO_DATE('20200229 235959', 'YYYYMMDD HH24MISS')
GROUP BY TO_CHAR(DT, 'YYYYMMDD');

SELECT *
FROM
(SELECT TO_DATE('20200201', 'YYYYMMDD') + (LEVEL-1) d
 FROM DUAL
 CONNECT BY LEVEL <=29)
WHERE EXISTS (SELECT 'X'
              FROM gis_dt
              WHERE dt BETWEEN d and TO_DATE( TO_CHAR(d, 'YYYYMMDD') || '235959', 'YYYYMMDDHH24MISS' ));

SELECT TO_CHAR(DT, 'YYYYMMDD')
FROM gis_dt
WHERE DT BETWEEN TO_DATE('20200201', 'YYYYMMDD') AND TO_DATE('20200229 235959', 'YYYYMMDD HH24MISS')


SELECT COUNT(*)
FROM gis_dt
WHERE DT BETWEEN TO_DATE('20200201', 'YYYYMMDD') AND TO_DATE('20200229 235959', 'YYYYMMDD HH24MISS');
   
SELECT *
FROM TABLE(DBMS_XPLAN.DISPLAY);
   